package uk.ac.wlv.blogclient.data.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "posts")

public class Post {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public String title;
    public String body;
    public String imageUri;    // stores content:// URI as string (gallery/camera)
    public long createdAt;     // epoch millis
    public long updatedAt;     // epoch millis

    public boolean uploaded; // upload status
    public String uploadUrl;   // link/identifier after upload

    public Post(String title, String body, String imageUri,
                long createdAt, long updatedAt,
                boolean uploaded, String uploadUrl) {
        this.title = title;
        this.body = body;
        this.imageUri = imageUri;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.uploaded = uploaded;
        this.uploadUrl = uploadUrl;
    }
}

