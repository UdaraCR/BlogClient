package uk.ac.wlv.blogclient.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import uk.ac.wlv.blogclient.R;
import uk.ac.wlv.blogclient.data.model.Post;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.VH> {

    public interface OnItemClick {
        void onClick(Post post);
    }

    public interface OnSelectionChanged {
        void onSelectionChanged(int count);
    }

    private final List<Post> items = new ArrayList<>();
    private final Set<Long> selectedIds = new HashSet<>();

    private final OnItemClick onItemClick;
    private final OnSelectionChanged onSelectionChanged;

    public PostAdapter(OnItemClick onItemClick, OnSelectionChanged onSelectionChanged) {
        this.onItemClick = onItemClick;
        this.onSelectionChanged = onSelectionChanged;
    }

    public void setItems(List<Post> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        // Clear selection if items change (simple, reliable)
        selectedIds.clear();
        notifySelectionChanged();
        notifyDataSetChanged();
    }

    public List<Long> getSelectedIds() {
        return new ArrayList<>(selectedIds);
    }

    public int getSelectedCount() {
        return selectedIds.size();
    }

    public void clearSelection() {
        selectedIds.clear();
        notifySelectionChanged();
        notifyDataSetChanged();
    }

    private void toggleSelection(long id) {
        if (selectedIds.contains(id)) selectedIds.remove(id);
        else selectedIds.add(id);

        notifySelectionChanged();
        notifyDataSetChanged();
    }

    private void notifySelectionChanged() {
        if (onSelectionChanged != null) onSelectionChanged.onSelectionChanged(selectedIds.size());
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_post, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Post p = items.get(position);

        String title = (p.title == null || p.title.trim().isEmpty()) ? "(No title)" : p.title;
        holder.tvTitle.setText(title);

        String body = (p.body == null) ? "" : p.body.trim();
        holder.tvBodyPreview.setText(body);

        holder.tvStatus.setText(p.uploaded ? "Uploaded" : "Offline");

        boolean selected = selectedIds.contains(p.id);
        holder.itemView.setAlpha(selected ? 0.6f : 1.0f);

        holder.itemView.setOnClickListener(v -> {
            if (getSelectedCount() > 0) {
                toggleSelection(p.id);
            } else if (onItemClick != null) {
                onItemClick.onClick(p);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            toggleSelection(p.id);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvBodyPreview, tvStatus;

        VH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvBodyPreview = itemView.findViewById(R.id.tvBodyPreview);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}
