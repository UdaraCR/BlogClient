package uk.ac.wlv.blogclient.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import uk.ac.wlv.blogclient.data.model.Post;

@Dao
public interface PostDao {

    @Insert
    long insert(Post post);

    @Update
    int update(Post post);

    @Query("DELETE FROM posts WHERE id = :id")
    int deleteById(long id);

    @Query("DELETE FROM posts WHERE id IN (:ids)")
    int deleteByIds(List<Long> ids);

    @Query("SELECT * FROM posts ORDER BY updatedAt DESC")
    List<Post> getAll();

    @Query("SELECT * FROM posts WHERE id = :id LIMIT 1")
    Post getById(long id);

    @Query("SELECT * FROM posts " +
            "WHERE title LIKE '%' || :q || '%' OR body LIKE '%' || :q || '%' " +
            "ORDER BY updatedAt DESC")
    List<Post> search(String q);

    @Query("UPDATE posts SET uploaded = :uploaded, uploadUrl = :uploadUrl, updatedAt = :updatedAt WHERE id = :id")
    int markUploaded(long id, boolean uploaded, String uploadUrl, long updatedAt);
}

