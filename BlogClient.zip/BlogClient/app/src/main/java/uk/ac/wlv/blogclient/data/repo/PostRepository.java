package uk.ac.wlv.blogclient.data.repo;

import android.content.Context;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import uk.ac.wlv.blogclient.data.dao.PostDao;
import uk.ac.wlv.blogclient.data.db.AppDatabase;
import uk.ac.wlv.blogclient.data.model.Post;

public class PostRepository {

    private final PostDao postDao;
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();

    public PostRepository(Context context) {
        postDao = AppDatabase.getInstance(context).postDao();
    }

    public Future<Long> insert(Post post) {
        return dbExecutor.submit(() -> postDao.insert(post));
    }

    public Future<Integer> update(Post post) {
        return dbExecutor.submit(() -> postDao.update(post));
    }

    public Future<Integer> deleteById(long id) {
        return dbExecutor.submit(() -> postDao.deleteById(id));
    }

    public Future<Integer> deleteByIds(List<Long> ids) {
        return dbExecutor.submit(() -> postDao.deleteByIds(ids));
    }

    public Future<List<Post>> getAll() {
        return dbExecutor.submit((Callable<List<Post>>) postDao::getAll);
    }

    public Future<Post> getById(long id) {
        return dbExecutor.submit(() -> postDao.getById(id));
    }

    public Future<List<Post>> search(String q) {
        return dbExecutor.submit(() -> postDao.search(q));
    }

    public Future<Integer> markUploaded(long id, boolean uploaded, String uploadUrl) {
        long now = System.currentTimeMillis();
        return dbExecutor.submit(() -> postDao.markUploaded(id, uploaded, uploadUrl, now));
    }
}


